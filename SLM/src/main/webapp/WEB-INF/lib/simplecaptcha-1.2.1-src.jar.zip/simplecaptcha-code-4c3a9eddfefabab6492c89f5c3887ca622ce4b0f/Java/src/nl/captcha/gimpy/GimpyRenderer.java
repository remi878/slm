package nl.captcha.gimpy;

import java.awt.image.BufferedImage;

/**
 * @author <a href="mailto:james.childers@gmail.com">James Childers</a>
 * 
 */

public interface GimpyRenderer {
    public void gimp(BufferedImage image);
}
