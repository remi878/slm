class BucketController {
    static navigation = [
        order:1
    ]

    def index = {
        render(view:"index")
    }
}
